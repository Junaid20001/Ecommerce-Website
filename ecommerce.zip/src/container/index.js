import Home from './Home';
import Shop from './Shop';
import Checkout from './Checkout';
import Cart from './Cart';

export {
    Home,
    Shop,
    Checkout,
    Cart
}